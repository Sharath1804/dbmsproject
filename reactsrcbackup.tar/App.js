import React, {Component} from 'react';
import Signup from './signuptest'
import TestEvents from './TestEvents'

class App extends Component {
    /*
    const colors = {
        correct : 'green',
        notfilled : 'white',
        filling : 'yellow',
        mistake : 'red'
    };
    */

    constructor() {
        super();
        this.state = {
            currentSection : 0,
        }
    }

    handleClick() {
        return;
    }

    render() {
        /*
        return (
            <div className="top">
            <header className="header">
            <h1>TestApp</h1>
            </header>
            <div class="main-div">
            First app
            </div>
            </div>
        );
        */
        return(<Signup />)
    }
}

export default App;
