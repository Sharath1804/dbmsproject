//Render login component
//if not authenticated, go back to login
import React from 'react';
import './auth'

class Login extends React.Component {
	constructor() {
		super();
		var state = {
			current : 'first'
		};
	}
    render() {
        return (
            <form onSubmit={this.loginPost}>
                <p>
                <input type="text" placeholder="username" ref="username" />
                </p>
                <p>
                <input type="password" placeholder="password" ref="pass" />
                </p>
                <p>
                <input type="submit" />
                </p>
            </form>
        )
    }
}


export default Login;
