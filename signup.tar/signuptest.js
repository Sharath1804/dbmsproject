import React from 'react';

class Signup extends React.Component {
	constructor() {
		super();
		this.state = {
			current : 1
		};
		this.handleNext = this.handleNext.bind(this);
		this.handleBack= this.handleBack.bind(this);
		this.requestObject = {
			name:'Testing',
			phone:'',
			age:'',
			sex:'',
			allergies:'',
			injuries:'',
			foods:'',
			workouts:'',
			supplements:'',
		};
	}

	handleNext() {

		var current = this.state.current;
		var currentUpdated = current+1;
		this.setState({
			current : currentUpdated
		});
	}

	handleUserSubmit() {
	}

	handleFinalSubmit() {
	}

	handleBack() {
		var current = this.state.current;
		var currentUpdated = current-1;
		this.setState({
			current : currentUpdated
		});
	}


	render() {
		if(this.state.current === 1)
			return (
				<div>
				<p>
				<h1>First Page. Username and password</h1>
				<input type="text" name="username" ref="username" placeholder="Testing" 
				defaultValue={this.requestObject.name}/>
				</p>
				<p>
				<button onClick={this.handleNext}>Next</button>
				</p>
				</div>
			)
		if(this.state.current === 2)
			return (
				<div>
				<p>
				<h1>Second Page. User Information </h1>
				</p>
				<p>
				<button onClick={this.handleBack}>Back</button>
				</p>
				<p>
				<button onClick={this.handleNext}>Next</button>
				</p>
				</div>
			)
		if(this.state.current === 3)
			return (
				<div>
				<p>
				<h1>Third Page.Form Plans</h1>
				</p>
				<p>
				<button onClick={this.handleBack}>Back</button>
				</p>
				<p>
				<button onClick={this.handleNext}>Next</button>
				</p>
				</div>
			)
		if(this.state.current === 4)
			return (
				<div>
				<p>
				<h1>Fourth Page.Verify data and submit.</h1>
				</p>

				<p>
				<button onClick={this.handleBack}>Back</button>
				</p>

				<p>
				<button onClick={this.handleSubmit}>Submit</button>
				</p>
				</div>
			)
	}
}


export default Signup;
